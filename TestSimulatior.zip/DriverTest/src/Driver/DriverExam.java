package Driver;

/* Class holds method to calculate
   how the user did on the exam. 
 */
public class DriverExam {

     //Array for correct answers
	 private String[] answers;     
	 //Array for user's answers
	 private String[] userInput;
	
	
	
	
	//Parameterized constructor to hold arrays
	public DriverExam(String[] answers, String[] userInput) {
	    this.answers = answers;
	    this.userInput = userInput;
	  }

	  
    //Returns the number of correct answers
	public int totalCorrect() {
		
      int count = 0;
		
	  for(int i = 0; i<answers.length; i++) {
	
	   if (answers[i].equals(userInput[i])) {
	    count++;
	
	  }
   }
	return count;

    }
	//Returns the number of incorrect answers
	public int totalIncorrect() {
		int count =0;
		
	for (int i =0; i < answers.length; i++)
		
		if (!answers[i].equals(userInput[i])) {
			count++;
		}
	return count;
		
	}
  
	//Returns the user's score
	public double YourScore() {
		double count = totalCorrect();
		
        
		 
		return count/15*100;
	
}

	
	
	//Returns string containing array of the questions missed
	public String questionsMissed() {
        
		String result = "";
		
		
		//Array for missed questions
        
        String[] wrongAnswers = new String[answers.length];
		
		for (int i = 0; i < answers.length ; i++) 
			
			if (!answers[i].equals(userInput[i])) {	
				
				Integer z = Integer.valueOf(i+1);
				
				wrongAnswers[i] = z.toString();
				
				result += wrongAnswers[i] + "/";
			}	
				
		if (result.equals("")) {
		      result = "You did not miss a single question! ";
		}
		
		return "The incorrect answers are: " + result;
	
	
	}
	
	//Returns the user's passing status
	public boolean passed() {
		
		boolean result = false;
		
		double percent = YourScore();
		
		if (percent >= 65) {
			result = true;
		}
		return result;
		
		
	}
	
	
}
	  

     











