package Driver;

import java.util.Scanner;

//Creator: Satvir Hundal

/*This class is a demo of 
  a driver exam with 15 questions. 
 */

public class DriverDemo {

	//Main arg starts
	public static void main(String[] args) {

		 //Insert correct answers into array
		 
		 String answers[] = {"B", "D", "A", "A", "C", "A", "B", "A", "C", "D", "B", "C", "D", "A", "D"};
		 
		 //Array for user input
		
		 String[] userInput = new String[15];

         //Pass arrays into DriverExam constructor
		 
		 DriverExam demo = new DriverExam(answers, userInput);
         
         //------------------START OF EXAM--------------------
		 
		 //Ask user each of the fifteen questions and store input to the userInput array
		 
		 System.out.println("What is the answer to the first question on the driving exam? ");
         
         //Scanner object to scan user input
		 
		 Scanner scan = new Scanner(System.in);
         
         String op1 = scan.nextLine();
         
         //Check for invalid inputs
         
         while (!op1.equals("A") && !op1.equals("B") && !op1.equals("C") && !op1.equals("D")) {
        	 
        	 System.out.println("Please type a capital A, B, C, or D");
        	 op1 = scan.nextLine();
        	 
        	 userInput[0] = op1;
        	 
	}
         //Set to array
         userInput[0] = op1;
         
         
         System.out.println("What is the answer to the second question on the driving exam? ");
         
         String op2 = scan.nextLine();
         
         //Check for invalid inputs  
          
         while (!op2.equals("A") && !op2.equals("B") && !op2.equals("C") && !op2.equals("D")) {
        	 
        	 System.out.println("Please type a capital A, B, C, or D");
        	 op2 = scan.nextLine();
        	 
        	 userInput[1] = op2;
        	 
	}
         //Set to array
         userInput[1] = op2;
         
          
      
         System.out.println("What is the answer to the third question on the driving exam? ");
         
         
         String op3 = scan.nextLine();
         
         //Check for invalid inputs
         
         while (!op3.equals("A") && !op3.equals("B") && !op3.equals("C") && !op3.equals("D")) {
        	 
        	 System.out.println("Please type a capital A, B, C, or D");
        	 op3 = scan.nextLine();
        	 
        	 userInput[2] = op1;
        	 
	}
         //Set to array
         userInput[2] = op3;
         
         
         System.out.println("What is the answer to the fourth question on the driving exam? ");
         
         String op4 = scan.nextLine();
       //Check for invalid inputs
        while (!op4.equals("A") && !op4.equals("B") && !op4.equals("C") && !op4.equals("D")) {
        	 
        	 System.out.println("Please type a capital A, B, C, or D");
        	 op4 = scan.nextLine();
        	 
        	 userInput[3] = op4;
        	 
	}
        //Set to array
         userInput[3] = op4;
         
         
      System.out.println("What is the answer to the fifth question on the driving exam? ");
         
         
         String op5 = scan.nextLine();
       //Check for invalid inputs
         while (!op5.equals("A") && !op5.equals("B") && !op5.equals("C") && !op5.equals("D")) {
        	 
        	 System.out.println("Please type a capital A, B, C, or D");
        	 op5 = scan.nextLine();
        	 
        	 userInput[4] = op5;
        	 
	}
         //Set to array
         userInput[4] = op5;
         
         
         System.out.println("What is the answer to the sixth question on the driving exam? ");
         
         String op6 = scan.nextLine();
       //Check for invalid inputs
           while (!op6.equals("A") && !op6.equals("B") && !op6.equals("C") && !op6.equals("D")) {
        	 
        	 System.out.println("Please type a capital A, B, C, or D");
        	 op6 = scan.nextLine();
        	 
        	 userInput[5] = op6;
        	 
	}
           //Set to array
         userInput[5] = op6;
         
          
      
         System.out.println("What is the answer to the seventh question on the driving exam? ");
         
         
         String op7 = scan.nextLine();
       //Check for invalid inputs
         while (!op7.equals("A") && !op7.equals("B") && !op7.equals("C") && !op7.equals("D")) {
        	 
        	 System.out.println("Please type a capital A, B, C, or D");
        	 op7 = scan.nextLine();
        	 
        	 userInput[6] = op7;
        	 
	}
         //Set to array
         userInput[6] = op7;
         
         
         System.out.println("What is the answer to the eigth question on the driving exam? ");
         
         String op8 = scan.nextLine();
       //Check for invalid inputs
        while (!op8.equals("A") && !op8.equals("B") && !op8.equals("C") && !op8.equals("D")) {
        	 
        	 System.out.println("Please type a capital A, B, C, or D");
        	 op8 = scan.nextLine();
        	 
        	 userInput[7] = op8;
        	 
	}
        //Set to array
         userInput[7] = op8;
         
         
    System.out.println("What is the answer to the ninth question on the driving exam? ");
         
         String op9 = scan.nextLine();
       //Check for invalid inputs
           while (!op9.equals("A") && !op9.equals("B") && !op9.equals("C") && !op9.equals("D")) {
        	 
        	 System.out.println("Please type a capital A, B, C, or D");
        	 op9 = scan.nextLine();
        	 
        	 userInput[8] = op9;
        	 
	}
           //Set to array
         userInput[8] = op9;
         
          
      
         System.out.println("What is the answer to the tenth question on the driving exam? ");
         
         
         String op10 = scan.nextLine();
       //Check for invalid inputs
         while (!op10.equals("A") && !op10.equals("B") && !op10.equals("C") && !op10.equals("D")) {
        	 
        	 System.out.println("Please type a capital A, B, C, or D");
        	 op10 = scan.nextLine();
        	 
        	 userInput[9] = op10;
        	 
	}
         //Set to array
         userInput[9] = op10;
         
         
         System.out.println("What is the answer to the eleventh question on the driving exam? ");
         
         String op11 = scan.nextLine();
       //Check for invalid inputs
        while (!op11.equals("A") && !op11.equals("B") && !op11.equals("C") && !op11.equals("D")) {
        	 
        	 System.out.println("Please type a capital A, B, C, or D");
        	 op11 = scan.nextLine();
        	 
        	 userInput[10] = op11;
        	 
	}
        //Set to array
         userInput[10] = op11;
         
         
      System.out.println("What is the answer to the twelfth question on the driving exam? ");
         
         
         String op12 = scan.nextLine();
       //Check for invalid inputs
         while (!op12.equals("A") && !op12.equals("B") && !op12.equals("C") && !op12.equals("D")) {
        	 
        	 System.out.println("Please type a capital A, B, C, or D");
        	 op12 = scan.nextLine();
        	 
        	 userInput[11] = op12;
        	 
	}
         //Set to array
         userInput[11] = op12;
         
         
         System.out.println("What is the answer to the thirteenth question on the driving exam? ");
         
         String op13 = scan.nextLine();
       //Check for invalid inputs
           while (!op13.equals("A") && !op13.equals("B") && !op13.equals("C") && !op13.equals("D")) {
        	 
        	 System.out.println("Please type a capital A, B, C, or D");
        	 op13 = scan.nextLine();
        	 
        	 userInput[12] = op13;
        	 
	}
           //Set to array
         userInput[12] = op13;
         
          
      
         System.out.println("What is the answer to the fourteenth question on the driving exam? ");
         
         
         String op14 = scan.nextLine();
       //Check for invalid inputs
         while (!op14.equals("A") && !op14.equals("B") && !op14.equals("C") && !op14.equals("D")) {
        	 
        	 System.out.println("Please type a capital A, B, C, or D");
        	 op14 = scan.nextLine();
        	 
        	 userInput[13] = op14;
        	 
	}
         //Set to array
         userInput[13] = op14;
         
         
         System.out.println("What is the answer to the fifteenth question on the driving exam? ");
         
         String op15 = scan.nextLine();
       //Check for invalid inputs
        while (!op15.equals("A") && !op15.equals("B") && !op15.equals("C") && !op15.equals("D")) {
        	 
        	 System.out.println("Please type a capital A, B, C, or D");
        	 op15 = scan.nextLine();
        	 
        	 userInput[14] = op15;
        	 
	}
        //Set to array
         userInput[14] = op15;
         
         scan.close();
    
         
       //---------------END OF EXAM-----------------------
         
       //Print all methods on the demo exam
         
       System.out.println("The total correct answers are: " + demo.totalCorrect());
       
       System.out.println("The total incorrect answers are: " + demo.totalIncorrect());
       
       System.out.println("Your socre is: " + demo.YourScore() + " %");
       
       System.out.println("Passing status: " + demo.passed());
       
       System.out.println(demo.questionsMissed());

}
}
