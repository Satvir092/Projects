package application;
	
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Label;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.geometry.Pos;
import javafx.geometry.Insets;
//Creates a Shopping Cart UI
public class Main extends Application
{
   //Create ArrayLists for titles and prices
	
	ArrayList<String> titles = new ArrayList<>();
	
	ArrayList<Double> prices = new ArrayList<>();
	
	//Declare vars for tax and total
	double tax1 = 0;
	
	double total1 =0;
   
   public static void main(String[] args)
   {
      // Launch the application.
      launch(args);
   }
   
   @Override
   public void start(Stage primaryStage) throws FileNotFoundException
   {
      
	  //Read File
	  readCart();
	  // ListView sizes
      final double WIDTH = 120, HEIGHT = 140;
      
      // Create a ListView for titles
      ObservableList<String> titlesList = FXCollections.observableArrayList(titles);
      
      ListView<String> listView = new ListView<>(titlesList);
     
      listView.setPrefSize(WIDTH, HEIGHT);
     
      listView.getSelectionModel().setSelectionMode(
           SelectionMode.MULTIPLE);
     
     Label subtotal = new Label("-Subotal-");
     
     Label tax = new Label("-Tax-");
     
     Label total = new Label("-Total-");
      
      // Create an empty ListView to show the titles the user selected
      ListView<String> listView2 = new ListView<>();
      listView2.setPrefSize(WIDTH, HEIGHT);
      
      // Create a Button to add to cart
      Button addButton = new Button("Add");
      
      
      // Add items to the cart
      addButton.setOnAction(event ->
      {
         
         ObservableList<String> selections =
            listView.getSelectionModel().getSelectedItems();
         
         
         listView2.getItems().setAll(selections);
      });
  //Clears all selections    
  Button clearButton = new Button("Clear");
      
      clearButton.setOnAction (event ->
      {
    	  listView2.getItems().setAll();  
      });
      
     Button removeButton = new Button("Remove");
      
      
     //Remove all items in the carts
      removeButton.setOnAction(event ->
      {
        
         ObservableList<String> selectionsRemover =
            listView.getSelectionModel().getSelectedItems();
         
         
         listView2.getItems().removeAll(selectionsRemover);
      });
      
     Button checkout = new Button("Checkout");
       
     //Calculate total, subtotal, and tax
     checkout.setOnAction(event -> {
    	    
    	 if (listView.getSelectionModel().getSelectedIndex() != -1) {
    	        
    		 ObservableList<String> selections4 = listView.getSelectionModel().getSelectedItems();

    	        double subtotal1 = 0;
    	        
    	        for (String num : selections4) {
    	            
    	        	int selectedIndex = titles.indexOf(num);
    	            
    	            subtotal1 += prices.get(selectedIndex);
    	        }
                
    	        tax1 = subtotal1*0.07;
    	        
    	        total1 = tax1 + subtotal1;
    	        
    	        
    	        String roundedTax = String.format("%.2f", tax1);
    	        
    	        String roundedTotal = String.format("%.2f", total1);
    	        
    	        String roundedSubtotal = String.format("%.2f", subtotal1);
    	        
    	        
    	        total.setText("$" + roundedTotal);
    	        
    	        tax.setText("$" + roundedTax);
    	        
    	        subtotal.setText("$" + roundedSubtotal);
    	    }
    	});
      
      // Add the controls to a VBox.
      VBox vbox = new VBox(10, listView, 
                           listView2, addButton, clearButton, removeButton, checkout, subtotal, tax, total);
      vbox.setPadding(new Insets(10));
      vbox.setAlignment(Pos.CENTER);
               
      // Create a Scene and display it.
      Scene scene = new Scene(vbox);
      primaryStage.setScene(scene);
      primaryStage.show();
   }
   
   public void readCart() throws FileNotFoundException {
	   
	   File bookFile = new File("C:\\Users\\Satvir Hundal\\Downloads\\SourceCode\\BookPrices.txt");
	   
	   Scanner scan = new Scanner(bookFile);
	   
	   String userInput= "";
	   
	   //Scan through each line and split titles and prices
	   while (scan.hasNextLine()) {
		   
		   userInput = scan.nextLine();
		   
		   String [] splitList = userInput.split(",");
		   
		   titles.add(splitList[0]);
		   prices.add(Double.parseDouble(splitList[1]));
	   
	   }
	   
	   scan.close();
	   
   }
}

